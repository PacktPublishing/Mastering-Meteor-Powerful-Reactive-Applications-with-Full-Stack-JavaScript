Template.checkout.helpers({
    isCheckingOut:function(){
        debugger
        return Session.equals('isCheckingOut',true);
    }
});
