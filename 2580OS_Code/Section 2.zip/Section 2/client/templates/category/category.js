Template.category.helpers({
    categoryName:function(){
        return FlowRouter.getParam('categoryName');
    }
});

