Template.cart.helpers({
    cartitems:function(){
        var item = {description:'<b>Great</b> Scent',img:'/images/apple-crisp-16.jpg',product:'Apple Cinnamon',qty:2,price:12.00}
        return [item];
    }
});
