(function(){
Template.__checkName("category");
Template["category"] = new Template("Template.category", (function() {
  var view = this;
  return HTML.DIV({
    "class": "page-header"
  }, "\n\n        ", HTML.H1(Blaze.View("lookup:categoryName", function() {
    return Spacebars.mustache(view.lookup("categoryName"));
  })), "\n\n    ");
}));

})();
