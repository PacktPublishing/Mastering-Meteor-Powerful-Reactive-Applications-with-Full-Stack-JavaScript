(function(){
Template.__checkName("profile");
Template["profile"] = new Template("Template.profile", (function() {
  var view = this;
  return HTML.DIV({
    "class": "col-md-6"
  }, HTML.Raw('\n      <h2 class="head-snippet">User Profile</h2>\n\n      '), HTML.FORM("\n          ", HTML.DIV({
    "class": "form-group"
  }, "\n              ", HTML.Raw('<label class="control-label">First Name</label>'), "\n              ", HTML.INPUT({
    type: "text",
    id: "firstname",
    "class": "form-control input-sm",
    value: function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("currentUser"), "profile", "firstname"));
    }
  }), "\n          "), "\n          ", HTML.DIV({
    "class": "form-group"
  }, "\n              ", HTML.Raw('<label class="control-label">Last Name</label>'), "\n              ", HTML.INPUT({
    value: function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("currentUser"), "profile", "lastname"));
    },
    type: "text",
    id: "lastname",
    "class": "form-control input-sm"
  }), "\n          "), "\n          ", HTML.DIV({
    "class": "form-group"
  }, "\n              ", HTML.Raw('<label class="control-label">Email</label>'), "\n              ", HTML.INPUT({
    value: function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("currentUser"), "profile", "email"));
    },
    type: "text",
    id: "email",
    "class": "form-control input-sm"
  }), "\n          "), "\n          ", HTML.DIV({
    "class": "form-group"
  }, "\n              ", HTML.Raw('<label class="control-label">Password</label>'), "\n              ", HTML.INPUT({
    value: function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("currentUser"), "profile", "password"));
    },
    type: "password",
    id: "password",
    "class": "form-control input-sm"
  }), "\n          "), "\n          ", HTML.Raw('<label class="control-label">Avatar</label>'), "\n          ", HTML.DIV({
    "class": "col-md-12"
  }, "\n              ", HTML.Raw('<div class="col-md-6">\n                  <span class="btn btn-success btn-file">\n                      Browse...\n                      <input type="file" accept=".gif,.jpg,.png" class="myFileInput" id="avatar">\n                  </span>\n              </div>'), "\n              ", HTML.DIV({
    "class": "col-md-6"
  }, "\n                  ", HTML.IMG({
    src: function() {
      return Spacebars.mustache(Spacebars.dot(view.lookup("currentUser"), "profile", "avatar"));
    },
    alt: "Avatar",
    width: "40px",
    "class": "img-circle avatar-upload"
  }), "\n              "), "\n          "), "\n          ", HTML.Raw('<div class="col-md-12">\n              <a href="#" class="btn btn-info center-block saveProfileBtn">Save Profile</a>\n          </div>'), "\n      "), "\n  ");
}));

})();
