Meteor.Paypal.config({
    'host':'api.sandbox.paypal.com',
    'port':'',
    'client_id':'ClientId',
    'client_secret':'ClientSecret'
});