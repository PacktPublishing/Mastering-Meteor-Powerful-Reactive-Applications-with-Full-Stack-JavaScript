module.exports = function(config) {
  config.set({
  "port": 9876,
  "basePath": "/Users/georgemcknight/Desktop/Mastering Meteor JS/Movies/12_Integrating-Frameworks/12.1-Add_React_Functionality/quietearth",
  "frameworks": [
    "jasmine"
  ],
  "browsers": [
    "Chrome"
  ],
  "plugins": [
    "karma-jasmine",
    "karma-chrome-launcher",
    "karma-coffee-preprocessor"
  ],
  "files": [
    ".meteor/local/build/programs/server/assets/packages/sanjo_jasmine/src/client/unit/assets/__meteor_runtime_config__.js",
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/underscore.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/meteor.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/json.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/base64.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/ejson.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/logging.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    ".meteor/local/build/programs/server/assets/packages/sanjo_jasmine/src/client/unit/assets/mocks/packages/reload.js",
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/tracker.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/random.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/retry.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/check.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/id-map.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/ordered-dict.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/geojson-utils.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/minimongo.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/ddp.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/mongo.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    ".meteor/local/build/programs/server/assets/packages/sanjo_jasmine/src/client/unit/assets/mocks/packages/autoupdate.js",
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/meteor-platform.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/jquery.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/deps.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/htmljs.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/observe-sequence.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/reactive-var.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/blaze.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/templating.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/reactive-dict.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/meteorhacks_flow-layout.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cosmos_browserify.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/kadira_flow-router/client.browserify.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/kadira_flow-router.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/twbs_bootstrap.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/npm-bcrypt.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/localstorage.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/callback-hook.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/accounts-base.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/sha.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/srp.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/accounts-password.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/alanning_roles.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/fortawesome_fontawesome.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_standard-packages.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_base-package.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/livedata.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/mongo-livedata.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/raix_eventemitter.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_storage-adapter/packages/cfs_storage-adapter.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_gridfs.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/matb33_collection-hooks.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/dburles_collection-helpers.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/aldeed_simple-schema.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/aldeed_collection2.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/url.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/http.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/webapp.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/velocity_meteor-internals.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/velocity_source-map-support.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/velocity_core.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/velocity_shim.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/simple_json-routes.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/sanjo_long-running-child-process.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/grigio_babel.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/amplify.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/less.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/xolvio_cucumber.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/velocity_console-reporter.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/coffeescript.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/practicalmeteor_chai.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/practicalmeteor_loglevel.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/velocity_meteor-stubs.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/arunoda_npm.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/mrt_paypal.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/react.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/session.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/ui.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/spacebars.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/launch-screen.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_data-man.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_file.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_tempstore.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_http-methods/packages/cfs_http-methods.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_http-publish.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_access-point.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_reactive-property.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_reactive-list.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_power-queue.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_upload-http.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_collection.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_collection-filters.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/cfs_worker.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/jsx.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/react-runtime-dev.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/react-runtime-prod.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/react-runtime.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/babel-runtime.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/react-meteor-data.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/global-imports.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/service-configuration.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/twbs_bootstrap/dist/fonts/glyphicons-halflings-regular.eot",
      "watched": true,
      "included": false,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/twbs_bootstrap/dist/fonts/glyphicons-halflings-regular.svg",
      "watched": true,
      "included": false,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/twbs_bootstrap/dist/fonts/glyphicons-halflings-regular.ttf",
      "watched": true,
      "included": false,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/twbs_bootstrap/dist/fonts/glyphicons-halflings-regular.woff",
      "watched": true,
      "included": false,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/twbs_bootstrap/dist/fonts/glyphicons-halflings-regular.woff2",
      "watched": true,
      "included": false,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/fortawesome_fontawesome/upstream/fonts/fontawesome-webfont.eot",
      "watched": true,
      "included": false,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/fortawesome_fontawesome/upstream/fonts/fontawesome-webfont.svg",
      "watched": true,
      "included": false,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/fortawesome_fontawesome/upstream/fonts/fontawesome-webfont.ttf",
      "watched": true,
      "included": false,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/fortawesome_fontawesome/upstream/fonts/fontawesome-webfont.woff",
      "watched": true,
      "included": false,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/fortawesome_fontawesome/upstream/fonts/fontawesome-webfont.woff2",
      "watched": true,
      "included": false,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/fortawesome_fontawesome/upstream/fonts/FontAwesome.otf",
      "watched": true,
      "included": false,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/velocity_html-reporter/lib/velocity-logo.png",
      "watched": true,
      "included": false,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/velocity_html-reporter/lib/velocity_cog.svg",
      "watched": true,
      "included": false,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/velocity_html-reporter/lib/icon-time.png",
      "watched": true,
      "included": false,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/packages/velocity_meteor-stubs/index.js",
      "watched": true,
      "included": false,
      "served": true,
      "nocache": false
    },
    ".meteor/local/build/programs/server/assets/packages/sanjo_jasmine/src/client/unit/assets/jasmine-jquery.js",
    ".meteor/local/build/programs/server/assets/packages/sanjo_jasmine/.npm/package/node_modules/component-mocker/index.js",
    ".meteor/local/build/programs/server/assets/packages/sanjo_jasmine/src/lib/mock.js",
    ".meteor/local/build/programs/server/assets/packages/sanjo_jasmine/src/lib/VelocityTestReporter.js",
    ".meteor/local/build/programs/server/assets/packages/sanjo_jasmine/src/client/unit/assets/adapter.js",
    ".meteor/local/build/programs/server/assets/packages/velocity_meteor-stubs/index.js",
    ".meteor/local/build/programs/server/assets/packages/sanjo_jasmine/src/client/unit/assets/helpers/iron_router.js",
    "tests/jasmine/client/unit/**/*-+(stub|stubs|mock|mocks).+(js|coffee|litcoffee|coffee.md)",
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/admin/template.admin.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/admin/template.unauthorized.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/cart/template.cart.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/category/template.category.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/checkout/template.checkout.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/header/template.header.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/home/template.home.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/layout/template.layout.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/product/template.product.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/profile/template.profile.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/register/template.register.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/reusables/template.panel.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/sidebar/template.sidebar.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/signin/template.signin.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/template.quietearth.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/admin/admin.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/cart/cart.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/category/category.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/checkout/checkout.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/header/header.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/home/home.jsx.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/home/task.jsx.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/product/product.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/profile/profile.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/register/register.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/reusables/panel.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/sidebar/sidebar.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/templates/signin/signin.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/both/collections/cart.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/both/collections/category.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/both/collections/fileuploads.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/both/collections/product.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/both/router/routes.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/client/helpers/stringHelpers.js",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/501c86a631f79ed6c0309a53fefe77d810d32fba.css",
      "watched": true,
      "included": true,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/images/almost-paradise-16.jpg",
      "watched": true,
      "included": false,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/images/apple-crisp-16.jpg",
      "watched": true,
      "included": false,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/images/avatar.png",
      "watched": true,
      "included": false,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/app/images/carrot-cake-16.jpg",
      "watched": true,
      "included": false,
      "served": true,
      "nocache": false
    },
    {
      "pattern": ".meteor/local/build/programs/web.browser/head.html",
      "watched": true,
      "included": false,
      "served": true,
      "nocache": false
    },
    "tests/jasmine/client/unit/**/*.+(js|coffee|litcoffee|coffee.md)"
  ],
  "proxies": {
    "/packages/twbs_bootstrap/dist/fonts/glyphicons-halflings-regular.eot": "/base/.meteor/local/build/programs/web.browser/packages/twbs_bootstrap/dist/fonts/glyphicons-halflings-regular.eot",
    "/packages/twbs_bootstrap/dist/fonts/glyphicons-halflings-regular.svg": "/base/.meteor/local/build/programs/web.browser/packages/twbs_bootstrap/dist/fonts/glyphicons-halflings-regular.svg",
    "/packages/twbs_bootstrap/dist/fonts/glyphicons-halflings-regular.ttf": "/base/.meteor/local/build/programs/web.browser/packages/twbs_bootstrap/dist/fonts/glyphicons-halflings-regular.ttf",
    "/packages/twbs_bootstrap/dist/fonts/glyphicons-halflings-regular.woff": "/base/.meteor/local/build/programs/web.browser/packages/twbs_bootstrap/dist/fonts/glyphicons-halflings-regular.woff",
    "/packages/twbs_bootstrap/dist/fonts/glyphicons-halflings-regular.woff2": "/base/.meteor/local/build/programs/web.browser/packages/twbs_bootstrap/dist/fonts/glyphicons-halflings-regular.woff2",
    "/packages/fortawesome_fontawesome/upstream/fonts/fontawesome-webfont.eot": "/base/.meteor/local/build/programs/web.browser/packages/fortawesome_fontawesome/upstream/fonts/fontawesome-webfont.eot",
    "/packages/fortawesome_fontawesome/upstream/fonts/fontawesome-webfont.svg": "/base/.meteor/local/build/programs/web.browser/packages/fortawesome_fontawesome/upstream/fonts/fontawesome-webfont.svg",
    "/packages/fortawesome_fontawesome/upstream/fonts/fontawesome-webfont.ttf": "/base/.meteor/local/build/programs/web.browser/packages/fortawesome_fontawesome/upstream/fonts/fontawesome-webfont.ttf",
    "/packages/fortawesome_fontawesome/upstream/fonts/fontawesome-webfont.woff": "/base/.meteor/local/build/programs/web.browser/packages/fortawesome_fontawesome/upstream/fonts/fontawesome-webfont.woff",
    "/packages/fortawesome_fontawesome/upstream/fonts/fontawesome-webfont.woff2": "/base/.meteor/local/build/programs/web.browser/packages/fortawesome_fontawesome/upstream/fonts/fontawesome-webfont.woff2",
    "/packages/fortawesome_fontawesome/upstream/fonts/FontAwesome.otf": "/base/.meteor/local/build/programs/web.browser/packages/fortawesome_fontawesome/upstream/fonts/FontAwesome.otf",
    "/packages/velocity_html-reporter/lib/velocity-logo.png": "/base/.meteor/local/build/programs/web.browser/packages/velocity_html-reporter/lib/velocity-logo.png",
    "/packages/velocity_html-reporter/lib/velocity_cog.svg": "/base/.meteor/local/build/programs/web.browser/packages/velocity_html-reporter/lib/velocity_cog.svg",
    "/packages/velocity_html-reporter/lib/icon-time.png": "/base/.meteor/local/build/programs/web.browser/packages/velocity_html-reporter/lib/icon-time.png",
    "/packages/velocity_meteor-stubs/index.js": "/base/.meteor/local/build/programs/web.browser/packages/velocity_meteor-stubs/index.js",
    "/images/almost-paradise-16.jpg": "/base/.meteor/local/build/programs/web.browser/app/images/almost-paradise-16.jpg",
    "/images/apple-crisp-16.jpg": "/base/.meteor/local/build/programs/web.browser/app/images/apple-crisp-16.jpg",
    "/images/avatar.png": "/base/.meteor/local/build/programs/web.browser/app/images/avatar.png",
    "/images/carrot-cake-16.jpg": "/base/.meteor/local/build/programs/web.browser/app/images/carrot-cake-16.jpg"
  },
  "client": {
    "contextFile": "/Users/georgemcknight/Desktop/Mastering Meteor JS/Movies/12_Integrating-Frameworks/12.1-Add_React_Functionality/quietearth/.meteor/local/karma/jasmine-client-unit/context.html",
    "debugFile": "/Users/georgemcknight/Desktop/Mastering Meteor JS/Movies/12_Integrating-Frameworks/12.1-Add_React_Functionality/quietearth/.meteor/local/karma/jasmine-client-unit/debug.html",
    "args": [
      {
        "autoupdateVersion": "unknown",
        "autoupdateVersionRefreshable": "unknown",
        "autoupdateVersionCordova": "none",
        "meteorRelease": "METEOR@1.1.0.3",
        "ROOT_URL": "http://localhost:3000/",
        "ROOT_URL_PATH_PREFIX": "",
        "appId": "1tdp9wq6dso4c7vn8io"
      }
    ]
  },
  "browserDisconnectTimeout": 10000,
  "browserNoActivityTimeout": 15000,
  "preprocessors": {
    "**/*.{coffee,litcoffee,coffee.md}": [
      "coffee"
    ]
  },
  "coffeePreprocessor": {
    "options": {
      "bare": true,
      "sourceMap": true
    }
  }
});
};