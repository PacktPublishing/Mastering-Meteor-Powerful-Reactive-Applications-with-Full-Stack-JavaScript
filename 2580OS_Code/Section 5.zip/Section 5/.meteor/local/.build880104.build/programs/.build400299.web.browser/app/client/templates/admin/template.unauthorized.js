(function(){
Template.__checkName("unauthorized");
Template["unauthorized"] = new Template("Template.unauthorized", (function() {
  var view = this;
  return HTML.Raw('<h1>UnAuthorized</h1>\n    <a href="/home">Back to Home</a>');
}));

})();
